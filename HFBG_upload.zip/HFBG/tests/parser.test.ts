import { describe, it, expect } from 'vitest';
import { parseWebhookPayload } from '../src/utils/parser.js';

describe('parseWebhookPayload', () => {
  describe('storeName extraction', () => {
    it('should extract store name with 점 suffix', () => {
      const result = parseWebhookPayload({
        title: '강남점에서 받은 리뷰',
        body: '좋은 서비스였습니다',
      });
      expect(result.storeName).toBe('강남점');
    });

    it('should extract store name from brackets', () => {
      const result = parseWebhookPayload({
        title: '[서초지점] 새로운 리뷰',
        body: '만족합니다',
      });
      expect(result.storeName).toBe('서초지점');
    });

    it('should return UNKNOWN for no store pattern', () => {
      const result = parseWebhookPayload({
        body: '리뷰 내용만 있습니다',
      });
      expect(result.storeName).toBe('UNKNOWN');
    });
  });

  describe('rating extraction', () => {
    it('should extract rating with 점 format', () => {
      const result = parseWebhookPayload({
        title: '5점 리뷰',
        body: '최고입니다',
      });
      expect(result.rating).toBe('5');
    });

    it('should extract rating with /5 format', () => {
      const result = parseWebhookPayload({
        description: '평점: 4.5/5',
      });
      expect(result.rating).toBe('4.5');
    });

    it('should count star symbols', () => {
      const result = parseWebhookPayload({
        title: '★★★★ 리뷰',
      });
      expect(result.rating).toBe('4');
    });

    it('should return empty for no rating', () => {
      const result = parseWebhookPayload({
        body: '좋았습니다',
      });
      expect(result.rating).toBe('');
    });
  });

  describe('reviewText extraction', () => {
    it('should prefer body for review text', () => {
      const result = parseWebhookPayload({
        title: '제목',
        description: '설명',
        body: '이것이 진짜 리뷰 내용입니다',
      });
      expect(result.reviewText).toBe('이것이 진짜 리뷰 내용입니다');
    });

    it('should fallback to description', () => {
      const result = parseWebhookPayload({
        title: '짧은 제목',
        description: '설명이 리뷰 내용입니다',
      });
      expect(result.reviewText).toBe('설명이 리뷰 내용입니다');
    });

    it('should combine all when body is short', () => {
      const result = parseWebhookPayload({
        title: '제목',
        description: '설명',
        body: '짧음',
      });
      expect(result.reviewText).toContain('제목');
    });
  });

  describe('date extraction', () => {
    it('should extract YYYY-MM-DD format', () => {
      const result = parseWebhookPayload({
        body: '2025-01-15에 방문했습니다',
      });
      expect(result.reviewCreatedAt).toBe('2025-01-15');
    });

    it('should extract Korean date format', () => {
      const result = parseWebhookPayload({
        body: '2025년 1월 5일 작성',
      });
      expect(result.reviewCreatedAt).toBe('2025-01-05');
    });

    it('should return empty for no date', () => {
      const result = parseWebhookPayload({
        body: '날짜 없는 리뷰',
      });
      expect(result.reviewCreatedAt).toBe('');
    });
  });

  describe('empty payload handling', () => {
    it('should handle completely empty payload', () => {
      const result = parseWebhookPayload({});
      expect(result.storeName).toBe('UNKNOWN');
      expect(result.rating).toBe('');
      expect(result.reviewText).toBe('');
      expect(result.reviewCreatedAt).toBe('');
    });
  });
});
