import { createHash } from 'crypto';

export function generateReviewId(
  storeName: string,
  rating: string,
  reviewText: string,
  reviewCreatedAt: string
): string {
  const input = `${storeName}|${rating}|${reviewText}|${reviewCreatedAt || ''}`;
  const hash = createHash('sha256').update(input, 'utf8').digest('hex');
  return hash.slice(0, 20);
}
