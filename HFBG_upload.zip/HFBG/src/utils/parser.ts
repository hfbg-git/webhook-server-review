import { WebhookPayload } from '../types/index.js';

export interface ParsedData {
  storeName: string;
  rating: string;
  reviewText: string;
  reviewCreatedAt: string;
}

export function parseWebhookPayload(payload: WebhookPayload): ParsedData {
  const title = payload.title || '';
  const description = payload.description || '';
  const body = payload.body || '';

  const combinedText = [title, description, body].filter(Boolean).join('\n');

  return {
    storeName: extractStoreName(combinedText),
    rating: extractRating(combinedText),
    reviewText: extractReviewText(title, description, body),
    reviewCreatedAt: extractDate(combinedText),
  };
}

function extractStoreName(text: string): string {
  // Pattern 1: [지점명] or (지점명)
  const bracketMatch = text.match(/[\[\(]([^\]\)]+(?:지점|점|매장|센터|병원|의원)[^\]\)]*)[\]\)]/);
  if (bracketMatch) {
    return bracketMatch[1].trim();
  }

  // Pattern 2: ~지점, ~점, ~매장
  const storePatterns = [
    /([가-힣A-Za-z0-9\s]+(?:지점|점|매장|센터|병원|의원))/,
    /([가-힣]+\s*(?:점|지점))/,
  ];

  for (const pattern of storePatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  return 'UNKNOWN';
}

function extractRating(text: string): string {
  // Pattern 1: X점 or X.X점
  const scoreMatch = text.match(/(\d(?:\.\d)?)\s*점/);
  if (scoreMatch) {
    return scoreMatch[1];
  }

  // Pattern 2: X/5 or X.X/5
  const slashMatch = text.match(/(\d(?:\.\d)?)\s*\/\s*5/);
  if (slashMatch) {
    return slashMatch[1];
  }

  // Pattern 3: Count stars ★
  const starCount = (text.match(/★/g) || []).length;
  if (starCount > 0) {
    return String(starCount);
  }

  // Pattern 4: Count filled stars ⭐
  const emojiStarCount = (text.match(/⭐/g) || []).length;
  if (emojiStarCount > 0) {
    return String(emojiStarCount);
  }

  return '';
}

function extractReviewText(title: string, description: string, body: string): string {
  // Prefer body if it looks like review content
  if (body && body.length > 10) {
    return body.trim();
  }

  // Then description
  if (description && description.length > 10) {
    return description.trim();
  }

  // Combine all available text
  const combined = [title, description, body].filter(Boolean).join('\n').trim();
  return combined || '';
}

function extractDate(text: string): string {
  // Pattern 1: YYYY-MM-DD or YYYY/MM/DD
  const isoMatch = text.match(/(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
  if (isoMatch) {
    const year = isoMatch[1];
    const month = isoMatch[2].padStart(2, '0');
    const day = isoMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // Pattern 2: YYYY년 MM월 DD일
  const koreanMatch = text.match(/(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일/);
  if (koreanMatch) {
    const year = koreanMatch[1];
    const month = koreanMatch[2].padStart(2, '0');
    const day = koreanMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // Pattern 3: MM/DD/YYYY
  const usMatch = text.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (usMatch) {
    const month = usMatch[1].padStart(2, '0');
    const day = usMatch[2].padStart(2, '0');
    const year = usMatch[3];
    return `${year}-${month}-${day}`;
  }

  return '';
}
