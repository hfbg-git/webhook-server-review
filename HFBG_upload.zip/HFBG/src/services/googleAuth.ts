import { google, Auth } from 'googleapis';

let authClient: Auth.JWT | null = null;

export function getGoogleAuth() {
  if (authClient) {
    return authClient;
  }

  const serviceAccountJson = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!serviceAccountJson) {
    throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON environment variable is not set');
  }

  let credentials: {
    client_email: string;
    private_key: string;
  };

  try {
    credentials = JSON.parse(serviceAccountJson);
  } catch (error) {
    throw new Error('Failed to parse GOOGLE_SERVICE_ACCOUNT_JSON: ' + (error as Error).message);
  }

  const scopes =
    process.env.GOOGLE_PROJECT_SCOPES?.split(',') || [
      'https://www.googleapis.com/auth/drive.file',
      'https://www.googleapis.com/auth/spreadsheets',
    ];

  authClient = new google.auth.JWT({
    email: credentials.client_email,
    key: credentials.private_key,
    scopes,
  });

  return authClient;
}

export function getDriveClient() {
  return google.drive({ version: 'v3', auth: getGoogleAuth() });
}

export function getSheetsClient() {
  return google.sheets({ version: 'v4', auth: getGoogleAuth() });
}
