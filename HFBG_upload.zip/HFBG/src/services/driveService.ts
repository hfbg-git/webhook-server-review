import { getDriveClient } from './googleAuth.js';

const FOLDER_ID = process.env.RAW_SHEETS_FOLDER_ID || '';
const SHEET_PREFIX = process.env.RAW_SHEET_NAME_PREFIX || 'ReviewDoctor_Raw_';

export function getMonthlySheetName(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${SHEET_PREFIX}${year}_${month}`;
}

export async function findSpreadsheetByName(sheetName: string): Promise<string | null> {
  const drive = getDriveClient();

  const response = await drive.files.list({
    q: `name='${sheetName}' and '${FOLDER_ID}' in parents and mimeType='application/vnd.google-apps.spreadsheet' and trashed=false`,
    fields: 'files(id, name)',
    spaces: 'drive',
  });

  const files = response.data.files || [];
  if (files.length > 0 && files[0].id) {
    return files[0].id;
  }

  return null;
}

export async function createSpreadsheet(sheetName: string): Promise<string> {
  const drive = getDriveClient();

  const response = await drive.files.create({
    requestBody: {
      name: sheetName,
      mimeType: 'application/vnd.google-apps.spreadsheet',
      parents: [FOLDER_ID],
    },
    fields: 'id',
  });

  const fileId = response.data.id;
  if (!fileId) {
    throw new Error('Failed to create spreadsheet: no file ID returned');
  }

  return fileId;
}

export async function getOrCreateMonthlySpreadsheet(): Promise<{ spreadsheetId: string; sheetName: string }> {
  const sheetName = getMonthlySheetName();

  let spreadsheetId = await findSpreadsheetByName(sheetName);

  if (!spreadsheetId) {
    spreadsheetId = await createSpreadsheet(sheetName);
  }

  return { spreadsheetId, sheetName };
}
