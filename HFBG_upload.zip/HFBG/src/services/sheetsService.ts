import { getSheetsClient } from './googleAuth.js';
import { REVIEWS_HEADERS, ParsedReview } from '../types/index.js';

const REVIEWS_TAB = 'Reviews';
const DUP_CHECK_ROWS = parseInt(process.env.DUP_CHECK_LOOKBACK_ROWS || '2000', 10);

export async function ensureReviewsTab(spreadsheetId: string): Promise<void> {
  const sheets = getSheetsClient();

  const spreadsheet = await sheets.spreadsheets.get({
    spreadsheetId,
    fields: 'sheets.properties.title',
  });

  const existingSheets = spreadsheet.data.sheets || [];
  const hasReviewsTab = existingSheets.some((sheet) => sheet.properties?.title === REVIEWS_TAB);

  if (!hasReviewsTab) {
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId,
      requestBody: {
        requests: [
          {
            addSheet: {
              properties: {
                title: REVIEWS_TAB,
              },
            },
          },
        ],
      },
    });
  }
}

export async function ensureHeaders(spreadsheetId: string): Promise<void> {
  const sheets = getSheetsClient();

  const response = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${REVIEWS_TAB}!A1:L1`,
  });

  const firstRow = response.data.values?.[0];

  if (!firstRow || firstRow.length === 0) {
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: `${REVIEWS_TAB}!A1`,
      valueInputOption: 'RAW',
      requestBody: {
        values: [REVIEWS_HEADERS as unknown as string[]],
      },
    });
  }
}

export async function checkDuplicateReviewId(
  spreadsheetId: string,
  reviewId: string
): Promise<boolean> {
  const sheets = getSheetsClient();

  const response = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${REVIEWS_TAB}!E2:E${DUP_CHECK_ROWS + 1}`,
  });

  const values = response.data.values || [];
  const existingIds = values.flat();

  return existingIds.includes(reviewId);
}

export async function appendReview(spreadsheetId: string, review: ParsedReview): Promise<void> {
  const sheets = getSheetsClient();

  const row = [
    review.receivedAt,
    review.reviewCreatedAt,
    review.storeName,
    review.rating,
    review.reviewId,
    review.title,
    review.description,
    review.body,
    review.reviewText,
    review.status,
    review.processedAt,
    review.errorMessage,
  ];

  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `${REVIEWS_TAB}!A:L`,
    valueInputOption: 'RAW',
    insertDataOption: 'INSERT_ROWS',
    requestBody: {
      values: [row],
    },
  });
}
