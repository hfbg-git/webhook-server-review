export interface WebhookPayload {
  title?: string;
  description?: string;
  body?: string;
}

export interface ParsedReview {
  receivedAt: string;
  reviewCreatedAt: string;
  storeName: string;
  rating: string;
  reviewId: string;
  title: string;
  description: string;
  body: string;
  reviewText: string;
  status: 'NEW';
  processedAt: string;
  errorMessage: string;
}

export interface WebhookResponse {
  ok: boolean;
  review_id: string;
  sheet_id: string;
  sheet_name: string;
  deduped: boolean;
}

export interface HealthResponse {
  ok: boolean;
}

export interface SheetInfo {
  spreadsheetId: string;
  sheetName: string;
}

export const REVIEWS_HEADERS = [
  'received_at',
  'review_created_at',
  'store_name',
  'rating',
  'review_id',
  'title',
  'description',
  'body',
  'review_text',
  'status',
  'processed_at',
  'error_message',
] as const;

export type ReviewHeader = (typeof REVIEWS_HEADERS)[number];
